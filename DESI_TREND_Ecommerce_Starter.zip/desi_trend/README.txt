DESI TREND - E-commerce starter website

HOW TO RUN
1. Extract the ZIP file.
2. Open the desi_trend folder.
3. Double-click index.html, or open it in Chrome.
4. Use Products to browse, Add to cart, Checkout to create a demo order.
5. Open admin/dashboard.html to view the demo admin area.
6. Add products from admin/products.html.

IMPORTANT LIMITATIONS
This package is a front-end starter/demo. Product, cart and order data are stored in the current browser using localStorage. They do NOT sync between customers/devices and may be lost if browser data is cleared.
Login/register screens are placeholders only. Admin pages are NOT protected. Do not use this as a live store or collect real customer data yet.
Online payment is not integrated. COD is only a demo checkout flow.

BEFORE GOING LIVE
- Connect Firebase Authentication for customer accounts.
- Create Firestore collections for products, users and orders.
- Set secure Firestore and Storage rules. Admin privileges must be verified server-side / through trusted claims, never by hiding a page link.
- Upload product images to Firebase Storage.
- Add a trusted backend function for order creation and inventory updates.
- Integrate a payment gateway (such as Razorpay) using its official server-side flow if online payments are needed.
- Add privacy policy, terms, shipping, returns/refund and contact pages.
- Test on mobile and desktop, and deploy over HTTPS.

FILES
index.html, products.html, product-details.html, cart.html, checkout.html,
login.html, register.html, my-orders.html, admin/*, css/style.css, js/app.js.
